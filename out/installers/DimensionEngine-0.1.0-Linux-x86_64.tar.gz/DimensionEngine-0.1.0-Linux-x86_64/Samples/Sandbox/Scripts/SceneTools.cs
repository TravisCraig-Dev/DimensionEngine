using System.Numerics;
using Dimension;

namespace Game
{
    public enum Axis { X, Y, Z }

    // Editor extensions (they run in the editor only): two menu commands and a window.
    public static class SceneTools
    {
        public static float Spacing = 2.0f;
        public static Axis LineUpAxis = Axis.X;
        // What Add Marker places (none: an empty object).
        public static Prefab MarkerPrefab;

        // Puts the selected objects in a row along LineUpAxis, Spacing apart, starting where the first one stands.
        [MenuItem("Tools/Line Up Selected")]
        public static void LineUpSelected()
        {
            Entity[] selected = Selection.Entities;
            if (selected.Length < 2) return;
            Undo.Record("Line Up Selected");
            Vector3 start = selected[0].Transform.Position;
            Vector3 along = LineUpAxis == Axis.X ? Vector3.UnitX : LineUpAxis == Axis.Y ? Vector3.UnitY : Vector3.UnitZ;
            for (int i = 1; i < selected.Length; ++i)
                selected[i].Transform.Position = start + along * (Spacing * i);
        }

        // A new object named Marker (an instance of MarkerPrefab, or empty), selected.
        [MenuItem("Tools/Add Marker")]
        public static void AddMarker()
        {
            Undo.Record("Add Marker");
            Selection.Active = MarkerPrefab.IsValid ? MarkerPrefab.Instantiate(Vector3.Zero) : EditorScene.CreateEntity("Marker");
        }
    }

    // Window > Scene Tools: the selected object's name and position, and the line-up spacing.
    [EditorWindow("Scene Tools", "Window/Scene Tools")]
    public class SceneToolsWindow : EditorWindow
    {
        public override void OnGUI()
        {
            EditorGUI.Separator("Selected");
            // Picking an object here selects it.
            Entity picked = EditorGUI.EntityField("Object", Selection.Active);
            if (picked != Selection.Active) Selection.Active = picked;
            Entity active = Selection.Active;
            if (!active.IsValid)
                EditorGUI.Label("Nothing selected.");
            else
            {
                string name = EditorGUI.TextField("Name", active.Name);
                if (name != active.Name)
                {
                    Undo.Record("Rename");
                    var e = active;
                    e.Name = name;
                }
                Vector3 position = active.Transform.Position;
                Vector3 moved = EditorGUI.Vector3Field("Position", position);
                if (moved != position)
                {
                    Undo.Record("Move");
                    active.Transform.Position = moved;
                }
                EditorGUI.Label($"{Selection.Entities.Length} selected");
            }
            EditorGUI.Separator("Line Up");
            SceneTools.Spacing = EditorGUI.Slider("Spacing", SceneTools.Spacing, 0.5f, 10.0f);
            SceneTools.LineUpAxis = EditorGUI.EnumField("Axis", SceneTools.LineUpAxis);
            SceneTools.MarkerPrefab = EditorGUI.AssetField("Marker Prefab", SceneTools.MarkerPrefab);
            if (EditorGUI.Button("Line Up Selected")) SceneTools.LineUpSelected();
            EditorGUI.SameLine();
            if (EditorGUI.Button("Add Marker")) SceneTools.AddMarker();
        }
    }
}
